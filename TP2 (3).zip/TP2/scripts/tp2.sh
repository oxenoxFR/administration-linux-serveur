#!/usr/bin/bash
# TP2 — Gestion avancée des utilisateurs et des groupes.
# Toutes les missions + bonus, avec archivage des preuves dans captures/.
# A lancer sur srv-core, en root :  bash tp2.sh      (relancable)
set -uo pipefail
source "$(dirname "$0")/lib.sh"
exiger_root; exiger_hote srv-core

PW='Helios-TP2-2026'      # mot de passe de TEST impose par l'enonce (comptes du lab)
T=/srv/helios/projets/transport
DATE="$(date +%F)"
# pty() : execute une commande dans un pseudo-terminal (su et passwd exigent un vrai terminal)
pty() { script -qec "$1" /dev/null; }

########################################################################
titre "MISSION 1 — Comptes, groupes et politique d'authentification"
########################################################################
F=m1-politique.txt; : > "$CAP/$F"
[[ -f /root/login.defs.orig ]] || cp -a /etc/login.defs /root/login.defs.orig
sed -i -e 's/^PASS_MAX_DAYS.*/PASS_MAX_DAYS\t90/' -e 's/^PASS_MIN_DAYS.*/PASS_MIN_DAYS\t1/' \
       -e 's/^PASS_WARN_AGE.*/PASS_WARN_AGE\t14/' -e 's/^UMASK.*/UMASK\t\t027/' /etc/login.defs
run $F "grep -E '^(PASS_|UMASK|USERGROUPS_ENAB|CREATE_HOME)' /etc/login.defs"
diff -u /root/login.defs.orig /etc/login.defs > "$CFG/login.defs.diff"
ok "configs/login.defs.diff genere"

install -d /etc/security/pwquality.conf.d
install -m 0644 "$CFG/50-helios.conf" /etc/security/pwquality.conf.d/50-helios.conf
run $F "cat /etc/security/pwquality.conf.d/50-helios.conf"

run $F "authselect current"
run $F "authselect enable-feature with-faillock"
sed -i -e 's/^# *deny *=.*/deny = 5/' -e 's/^# *unlock_time *=.*/unlock_time = 600/' \
       -e 's/^# *fail_interval *=.*/fail_interval = 900/' -e 's/^# *audit$/audit/' \
       /etc/security/faillock.conf
run $F "grep -Ev '^\s*(#|\$)' /etc/security/faillock.conf"
cp /etc/security/faillock.conf "$CFG/faillock.conf"

grep -q 'socle Helios' /etc/skel/.bashrc || cat "$CFG/skel-bashrc.ajout" >> /etc/skel/.bashrc

F=m1-comptes.txt; : > "$CAP/$F"
getent group transport  >/dev/null || groupadd -g 5000 transport
getent group telemetry  >/dev/null || groupadd -g 5001 telemetry
getent group helios-ops >/dev/null || groupadd -g 5002 helios-ops
id julien    &>/dev/null || useradd -u 5100 -g transport -G helios-ops -c "Julien Marty - chef equipe transport" -m julien
id nadia     &>/dev/null || useradd -u 5101 -g transport -c "Nadia Belkacem - exploitante" -m nadia
id tarek     &>/dev/null || useradd -u 5102 -g telemetry -G transport -c "Tarek Oualid - analyste telemetrie" -m tarek
id audit-ext &>/dev/null || useradd -u 5103 -g telemetry -c "Auditeur externe - mandat Q4" -m \
                              -e "$(date -d '+21 days' +%F)" -s /bin/bash audit-ext
for u in julien nadia tarek audit-ext; do
    echo "${u}:${PW}" | chpasswd
    chage -M 90 -m 1 -W 14 -I 7 "$u"
done
run $F "chage -l julien"
run $F "getent passwd julien nadia tarek audit-ext ; getent group transport telemetry helios-ops"
run $F "chage -l audit-ext | grep -i 'Account expires'"
valeur JULIEN_MAX "$(chage -l julien | awk -F': ' '/Maximum/ {print $2}')"
valeur JULIEN_WARN "$(chage -l julien | awk -F': ' '/warning/ {print $2}')"
valeur AUDIT_EXPIRE "$(chage -l audit-ext | awk -F': ' '/Account expires/ {print $2}')"

titre "1.3 — Administrateur de groupe"
run $F "gpasswd -A julien transport"
run $F "grep '^transport' /etc/group /etc/gshadow"
run $F "su - julien -c 'gpasswd -a nadia transport ; id nadia'"

F=m1-mdp-faible.txt; : > "$CAP/$F"
titre "1.3 — Refus d'un mot de passe faible (pam_pwquality)"
chage -d "$(date -d yesterday +%F)" julien
marque $F "passwd en julien, nouveau mot de passe « helios »"
(sleep 2; printf '%s\n' "$PW"; sleep 1; printf 'helios\n'; sleep 1; printf 'helios\n'; sleep 2) \
    | pty "su - julien -c passwd" 2>&1 | tr -d '\r' | tee -a "$CAP/$F"
if grep -q 'BAD PASSWORD' "$CAP/$F"; then
    ok "Mot de passe faible refuse"; valeur MDP_FAIBLE "$(grep -m1 'BAD PASSWORD' "$CAP/$F" | tr -d '\r')"
else
    ko "Pas de message BAD PASSWORD capture — refais le test a la main : su - julien puis passwd"
fi
marque $F "Controle complementaire avec pwscore"
command -v pwscore >/dev/null && { echo helios | pwscore 2>&1 | tee -a "$CAP/$F"; }

F=m1-faillock.txt; : > "$CAP/$F"
titre "1.3 — Verrouillage sur echecs (pam_faillock)"
faillock --user nadia --reset
marque $F "6 tentatives de su vers nadia avec un mauvais mot de passe, depuis tarek"
su - tarek -c "for i in \$(seq 1 6); do (sleep 1; printf 'mauvais\n') | script -qec 'su - nadia -c id' /dev/null >/dev/null 2>&1; done"
marque $F "AVANT reset"
run $F "faillock --user nadia"
ECHECS=$(faillock --user nadia | tail -n +3 | grep -c .)
valeur ECHECS "$ECHECS"
(( ECHECS >= 5 )) && ok "$ECHECS echecs enregistres -> nadia verrouillee" || ko "Seulement $ECHECS echec(s) enregistre(s)"
marque $F "APRES reset"
run $F "faillock --user nadia --reset ; faillock --user nadia"

########################################################################
titre "MISSION 2 — Bits speciaux et umask"
########################################################################
F=m2-setgid-sticky.txt; : > "$CAP/$F"
install -d -m 0755 /srv/helios/projets
install -d -m 2770 -o julien -g transport $T
install -d -m 0770 -o julien -g transport /srv/helios/projets/temoin
run $F "ls -ld $T /srv/helios/projets/temoin"
marque $F "Heritage setgid : fichier cree par tarek (groupe primaire telemetry)"
run $F "su - nadia -c 'touch $T/tournee-nadia.csv /srv/helios/projets/temoin/x'"
run $F "su - tarek -c 'touch $T/tournee-tarek.csv /srv/helios/projets/temoin/y ; ls -l $T/tournee-tarek.csv /srv/helios/projets/temoin/y'"
G1=$(stat -c %G $T/tournee-tarek.csv); G2=$(stat -c %G /srv/helios/projets/temoin/y)
valeur SETGID "transport/ -> groupe $G1 ; temoin/ -> groupe $G2"
[[ $G1 == transport && $G2 == telemetry ]] && ok "Heritage setgid prouve ($G1 / $G2)" || ko "setgid : $G1 / $G2"

marque $F "Sticky bit sur /srv/helios/depot"
install -d -m 1777 /srv/helios/depot
run $F "ls -ld /srv/helios/depot"
run $F "su - nadia -c 'echo n > /srv/helios/depot/fichier-nadia'"
run $F "su - tarek -c 'rm -f /srv/helios/depot/fichier-nadia'"; RC1=$?
marque $F "Sans sticky (0777)"
chmod 0777 /srv/helios/depot
run $F "su - tarek -c 'rm -f /srv/helios/depot/fichier-nadia'"; RC2=$?
chmod 1777 /srv/helios/depot
valeur STICKY "avec sticky rc=$RC1 (refuse) ; sans sticky rc=$RC2 (autorise)"
(( RC1 != 0 && RC2 == 0 )) && ok "Sticky : refus prouve" || ko "Sticky : rc=$RC1 / $RC2"

F=m2-umask.txt; : > "$CAP/$F"
rm -rf /tmp/u1 /tmp/u2 /tmp/u3 /tmp/d1 /tmp/d2
rm -f /etc/profile.d/helios-umask.sh
run $F "su - nadia -c 'umask ; touch /tmp/u1 ; mkdir /tmp/d1 ; ls -ld /tmp/u1 /tmp/d1'"
run $F "su - nadia -c 'umask 002 ; touch /tmp/u2 ; mkdir /tmp/d2 ; ls -ld /tmp/u2 /tmp/d2'"
run $F "su - nadia -c 'umask 077 ; touch /tmp/u3 ; ls -l /tmp/u3'"
valeur UMASK_DEF "$(su - nadia -c umask)"
valeur U1 "$(stat -c '%a' /tmp/u1) / dossier $(stat -c '%a' /tmp/d1)"
valeur U2 "$(stat -c '%a' /tmp/u2) / dossier $(stat -c '%a' /tmp/d2)"
valeur U3 "$(stat -c '%a' /tmp/u3)"
marque $F "umask par groupe (/etc/profile.d/helios-umask.sh)"
bash -n "$CFG/helios-umask.sh" && install -m 0644 "$CFG/helios-umask.sh" /etc/profile.d/helios-umask.sh
run $F "su - nadia -c 'umask ; touch $T/partage.txt ; ls -l $T/partage.txt'"
run $F "su - audit-ext -c 'umask'"
valeur UMASK_NADIA "$(su - nadia -c umask)"; valeur UMASK_AUDIT "$(su - audit-ext -c umask)"

F=m2-setuid.txt; : > "$CAP/$F"
marque $F "Inventaire setuid / setgid"
run $F "find / -xdev \\( -perm -4000 -o -perm -2000 \\) -type f -printf '%M %u %g %p\n' 2>/dev/null | sort"
marque $F "Le noyau ignore setuid sur un script"
printf '#!/usr/bin/bash\nid\n' > /usr/local/bin/faux-setuid.sh; chmod 4755 /usr/local/bin/faux-setuid.sh
run $F "ls -l /usr/local/bin/faux-setuid.sh"
run $F "su - nadia -c '/usr/local/bin/faux-setuid.sh'"
valeur FAUX_SETUID "$(su - nadia -c /usr/local/bin/faux-setuid.sh | cut -d' ' -f1)"
rm -f /usr/local/bin/faux-setuid.sh

marque $F "Binaire setgid legitime helios-lastlog"
rpm -q gcc &>/dev/null || run $F "dnf -y -q install gcc"
install -d /var/log/helios
install -m 0640 -o root -g telemetry /dev/null /var/log/helios/app.log
for i in $(seq 1 30); do echo "$(date --iso-8601=seconds) INFO trame ${i} ok" >> /var/log/helios/app.log; done
install -m 0644 "$CFG/helios-lastlog.c" /root/helios-lastlog.c
run $F "gcc -O2 -Wall -Wextra -o /usr/local/bin/helios-lastlog /root/helios-lastlog.c"
chown root:telemetry /usr/local/bin/helios-lastlog; chmod 2755 /usr/local/bin/helios-lastlog
run $F "ls -l /usr/local/bin/helios-lastlog"
run $F "su - julien -c 'tail -n 3 /var/log/helios/app.log'"; RCT=$?
run $F "su - julien -c '/usr/local/bin/helios-lastlog'"; RCL=$?
valeur LASTLOG "tail direct rc=$RCT (refuse) ; helios-lastlog rc=$RCL (OK)"
valeur LASTLOG_MODE "$(stat -c %A /usr/local/bin/helios-lastlog)"
(( RCT != 0 && RCL == 0 )) && ok "helios-lastlog : lecture via setgid OK" || ko "helios-lastlog : rc $RCT / $RCL"

########################################################################
titre "MISSION 3 — ACL POSIX"
########################################################################
F=m3-acl.txt; : > "$CAP/$F"
run $F "mount | grep ' / ' ; xfs_info / | head -3"
setfacl -R -b $T
marque $F "3.1 Acces nominatif de audit-ext"
run $F "setfacl -R -m u:audit-ext:rX $T"
run $F "getfacl $T ; ls -ld $T"
run $F "su - audit-ext -c 'ls -l $T/ ; cat $T/tournee-nadia.csv'"
run $F "su - audit-ext -c 'touch $T/interdit'"
marque $F "3.2 Sans ACL par defaut : un nouveau fichier echappe a la regle"
run $F "su - nadia -c 'touch $T/nouvelle.csv'"
run $F "su - audit-ext -c 'cat $T/nouvelle.csv'"; RCN=$?
marque $F "3.2 ACL par defaut"
run $F "setfacl -d -m u:audit-ext:r $T ; setfacl -d -m g:transport:rwx $T ; setfacl -d -m o::--- $T"
run $F "getfacl $T"
run $F "su - nadia -c 'touch $T/tournee-j2.csv ; mkdir -p $T/semaine-41'"
run $F "getfacl $T/tournee-j2.csv ; getfacl $T/semaine-41"
run $F "su - audit-ext -c 'cat $T/tournee-j2.csv'"; RCJ=$?
E1=$([[ $RCN == 0 ]] && echo "lisible via les droits « autres » (umask 002)" || echo refuse)
valeur ACL_DEFAUT "avant ACL par defaut : $E1 ; apres : lisible (rc=$RCJ)"
(( RCJ == 0 )) && ok "Fichier cree apres les ACL par defaut lisible par audit-ext" || ko "audit-ext ne lit pas tournee-j2.csv"

F=m3-masque.txt; : > "$CAP/$F"
run $F "setfacl -m u:tarek:rwx $T/tournee-j2.csv"
marque $F "AVANT chmod g-w"
run $F "getfacl $T/tournee-j2.csv"
run $F "chmod g-w $T/tournee-j2.csv"
marque $F "APRES chmod g-w"
run $F "getfacl $T/tournee-j2.csv"
run $F "su - tarek -c 'echo x >> $T/tournee-j2.csv'"; RCM1=$?
run $F "setfacl -m m::rwx $T/tournee-j2.csv"
run $F "su - tarek -c 'echo x >> $T/tournee-j2.csv'"; RCM2=$?
valeur MASQUE "apres chmod g-w rc=$RCM1 (refuse) ; apres m::rwx rc=$RCM2 (OK)"

F=m3-sauvegarde.txt; : > "$CAP/$F"
cd /srv/helios/projets || exit 1
run $F "getfacl -R transport > /root/acl-transport-$DATE.txt ; wc -l /root/acl-transport-$DATE.txt"
cp /root/acl-transport-$DATE.txt "$CFG/"
run $F "setfacl -R -b transport ; getfacl transport | head"
run $F "setfacl --restore=/root/acl-transport-$DATE.txt ; getfacl transport | head"
rm -rf transport-copie transport-copie2
run $F "cp -a transport transport-copie && getfacl transport-copie | head"
run $F "cp -r transport transport-copie2 && getfacl transport-copie2 | head"
run $F "tar --acls --xattrs -czf /root/transport.tgz transport ; tar --acls --xattrs -tvf /root/transport.tgz | head -3"
rm -rf transport-copie transport-copie2
cd - >/dev/null || exit 1

########################################################################
titre "MISSION 4 — Delegation sudo"
########################################################################
F=m4-sudo.txt; : > "$CAP/$F"
run $F "visudo -cf $CFG/90-helios-ops" || { ko "90-helios-ops invalide — arret"; exit 1; }
install -m 0440 "$CFG/90-helios-ops" /etc/sudoers.d/90-helios-ops
install -d -m 0700 /var/log/sudo-io
run $F "visudo -c"
run $F "sudo -l -U julien"
J() { echo "$PW" | su - julien -c "sudo -S -p '' $1" 2>&1; }
marque $F "Autorise : restart helios-collect"
J "systemctl restart helios-collect.service" | tee -a "$CAP/$F"; systemctl is-active -q helios-collect && ok "julien a redemarre helios-collect"
marque $F "Refuse : restart sshd"
J "systemctl restart sshd" | tee -a "$CAP/$F"
marque $F "En tant que helios"
J "-u helios cat /var/lib/helios/telemetry.csv" | tail -3 | tee -a "$CAP/$F"
marque $F "Journal"
J "journalctl -u helios-collect.service -n 5 --no-pager" | tee -a "$CAP/$F"
marque $F "nadia (hors groupe)"
echo "$PW" | su - nadia -c "sudo -S -p '' -l" 2>&1 | tee -a "$CAP/$F"
SL="$(sudo -l -U julien)"
[[ $SL == *"restart helios-collect.service"* && $SL != *sshd* ]] && ok "sudo -l -U julien : helios-collect oui, sshd non" || ko "sudo -l julien inattendu"

F=m4-tracabilite.txt; : > "$CAP/$F"
run $F "sudoreplay -l"
run $F "sudoreplay -l user julien"
TSID="$(sudoreplay -l user julien | tail -1 | sed -n 's/.*TSID=\([^ ]*\).*/\1/p')"
[[ -n $TSID ]] && run $F "sudoreplay -d 0 -m 0 $TSID < /dev/null"
run $F "tail -5 /var/log/sudo-helios.log ; journalctl -t sudo -n 10 --no-pager"
valeur SESSIONS_JULIEN "$(sudoreplay -l user julien 2>/dev/null | grep -c .)"

F=m4-evasion.txt; : > "$CAP/$F"
titre "4.3 — Regle laxiste : evasion de shell via sudo vim"
echo 'nadia ALL=(root) NOPASSWD: /usr/bin/vim /srv/helios/projets/transport/*' > /etc/sudoers.d/99-mauvais-exemple
chmod 0440 /etc/sudoers.d/99-mauvais-exemple
run $F "cat /etc/sudoers.d/99-mauvais-exemple ; visudo -c"
marque $F "nadia : sudo vim puis :!/usr/bin/id dans vim"
run $F "su - nadia -c \"id ; sudo vim -E -s -c '!/usr/bin/id' -c 'q!' $T/tournee-nadia.csv\""
grep -q 'uid=0(root)' "$CAP/$F" && { ok "Evasion prouvee : id -> root depuis vim"; valeur EVASION "uid=0(root) obtenu depuis vim"; } || ko "Evasion non capturee"
rm -f /etc/sudoers.d/99-mauvais-exemple
marque $F "Correction : sudoedit"
printf '%s\n' 'Defaults:nadia !sudoedit_checkdir' 'nadia ALL=(root) sudoedit /srv/helios/projets/transport/*' > /etc/sudoers.d/91-nadia-edition
chmod 0440 /etc/sudoers.d/91-nadia-edition
cp /etc/sudoers.d/91-nadia-edition "$CFG/"
run $F "visudo -c"
printf '#!/bin/sh\necho "# ligne ajoutee via sudoedit" >> "$1"\n' > /usr/local/bin/editeur-test; chmod 755 /usr/local/bin/editeur-test
run $F "su - nadia -c 'SUDO_EDITOR=/usr/local/bin/editeur-test sudoedit $T/tournee-nadia.csv' ; tail -1 $T/tournee-nadia.csv"
run $F "su - nadia -c \"sudo vim -E -s -c '!/usr/bin/id' -c 'q!' $T/tournee-nadia.csv\""
rm -f /usr/local/bin/editeur-test

########################################################################
titre "BONUS — Audit (commandes de l'enonce)"
########################################################################
F=bonus-audit.txt; : > "$CAP/$F"
run $F "awk -F: '\$3>=1000 && \$3<65534 {print \$1, \$3, \$7}' /etc/passwd"
run $F "awk -F: '(\$2==\"\"){print \$1\" SANS MOT DE PASSE\"}' /etc/shadow"
run $F "find /srv /home -xdev -perm -0002 -not -type l -printf '%M %p\n' 2>/dev/null"
run $F "find /srv /home -xdev -type d -perm -2000 -printf '%M %g %p\n' 2>/dev/null"
run $F "getfacl -R -s /srv/helios 2>/dev/null | grep -B4 '^user:'"

titre "Bilan TP2"
cp /etc/profile.d/helios-umask.sh "$CFG/" 2>/dev/null
grep -q '' "$VALEURS" && cat "$VALEURS"
info "Captures dans $CAP. Envoie-moi une capture de ce bilan."
