# TP2 — Gestion avancée des utilisateurs et des groupes

**David** · BTC2 Administration Linux Server · VM `srv-core` (Rocky Linux 9.8)

Vous trouverez mes fichiers de configuration dans `configs/` et toutes les sorties de commandes dans `captures/`.

---

## Mission 1 — Comptes et politique d'authentification

J'ai commencé par régler la politique de mots de passe **avant** de créer les comptes. Un compte récupère les règles en place au moment où il est créé, donc si on fait l'inverse, il faut tout repasser à la main.

- Dans **`login.defs`**, j'ai mis une durée de vie de 90 jours, un délai d'un jour minimum entre deux changements, un avertissement 14 jours avant l'expiration et un `UMASK` à 027. Le diff est dans `configs/login.defs.diff`.
- Avec **`pwquality`**, il faut au moins 12 caractères et 3 types de caractères différents, aucun mot du dictionnaire n'est accepté, et ces règles s'appliquent aussi à root.
- Pour **`faillock`**, le compte se bloque 10 minutes après 5 erreurs en 15 minutes.

Petite difficulté : la commande `authselect enable-feature with-faillock` ne marchait pas chez moi, parce que mon système n'était pas encore géré par authselect (« Aucune configuration n'a été détectée »). J'ai donc d'abord sélectionné un profil avec `authselect select … with-faillock`, et l'ancienne configuration PAM a été sauvegardée sous le nom `avant-tp2`. Le détail est dans `captures/m1-authselect.txt`.

J'ai ensuite créé les comptes :
- `julien`, le chef d'équipe, qui est aussi dans `helios-ops` ;
- `nadia` ;
- `tarek`, dont le groupe principal est `telemetry` ;
- `audit-ext`, l'auditeur externe, dont le compte **expire le 24 novembre 2026**, à la fin de sa mission de 3 semaines.

| Ce que j'ai vérifié | Ce que j'ai obtenu |
|---|---|
| `chage -l julien` | Expiration à 90 jours, avertissement à 14 jours |
| Changer le mot de passe pour `helios` | Refusé : `BAD PASSWORD: The password is shorter than 12 characters` |
| 6 mauvais mots de passe sur nadia | 5 échecs enregistrés, le compte est bloqué, puis `--reset` le débloque |

Avec `gpasswd -A julien transport`, Julien devient administrateur du groupe. Il a pu ajouter Nadia lui-même, sans passer par root.

![Mot de passe « helios » refusé par pam_pwquality](captures/ecrans/mdp-faible.png)
*Le mot de passe « helios » est refusé, il est trop court.*

![faillock : 5 échecs, le bon mot de passe est refusé, puis --reset](captures/ecrans/faillock.png)
*Après 5 échecs, même le bon mot de passe est refusé, jusqu'au `--reset`.*

---

## Mission 2 — Bits spéciaux et umask

### setgid et sticky bit

- J'ai mis le dossier `transport/` en **2770**, avec le bit setgid. Tout ce qui est créé dedans appartient automatiquement au groupe `transport`. Pour le vérifier, j'ai fait créer un fichier par tarek, dont le groupe principal est `telemetry` :
  - dans `transport/`, son fichier appartient au groupe **transport** ;
  - dans `temoin/`, qui n'a pas le setgid, il appartient au groupe **telemetry**.
- Le dossier `/srv/helios/depot` est en **1777**, avec le sticky bit. Tout le monde peut y déposer des fichiers, mais chacun ne peut supprimer que les siens :
  - avec le sticky bit, tarek n'a pas pu supprimer le fichier de nadia (« Opération non permise ») ;
  - quand je l'ai enlevé pour tester, la suppression est passée.

![Héritage setgid (transport vs telemetry) et refus du sticky bit](captures/ecrans/setgid-sticky.png)
*Le fichier de tarek prend le groupe `transport` grâce au setgid, et le sticky bit l'empêche de supprimer le fichier de nadia.*

### umask : prédiction puis vérification

Le umask de nadia était de `0027`. Pour prédire les droits, j'ai fait le calcul : 666 − umask pour un fichier, 777 − umask pour un dossier.

| Cas | Ce que j'avais prédit | Ce que j'ai observé |
|---|---|---|
| umask par défaut (027) | fichier 640, dossier 750 | fichier 640, dossier 750 |
| `umask 002` | fichier 664, dossier 775 | fichier 664, dossier 775 |
| `umask 077` | fichier 600 | fichier 600 |

Mes trois prédictions étaient justes. Ensuite, avec `/etc/profile.d/helios-umask.sh`, les membres de `transport` passent en `0002` pour pouvoir travailler à plusieurs sur les mêmes fichiers, tandis que les autres, comme audit-ext, restent en `0027`.

![umask mesuré pour les 3 cas, puis umask par groupe](captures/ecrans/umask.png)
*Les droits obtenus dans les trois cas, puis le umask par groupe.*

### setuid

La liste complète des binaires setuid et setgid du système est dans `captures/m2-setuid.txt`. Voici trois exemples, avec la raison de leur présence :
- **`passwd`** : un utilisateur doit pouvoir changer son mot de passe, ce qui veut dire écrire dans `/etc/shadow`, un fichier qui appartient à root.
- **`sudo`** : il a besoin de devenir root pour lancer les commandes autorisées dans `sudoers`.
- **`su`** : il doit pouvoir changer d'identité une fois le mot de passe vérifié.

J'ai aussi testé un script en 4755 qui lance `id` : il affiche toujours `uid=5101(nadia)` et pas root. Le noyau ignore volontairement le bit setuid sur les scripts, parce que ce serait trop facile à détourner.

Pour un cas d'usage propre, j'ai compilé `helios-lastlog` (`-rwxr-sr-x`). Il est setgid `telemetry`, et pas setuid root : il donne seulement le droit de lire `app.log`. Julien ne peut pas lire le journal directement avec `tail`, mais il y arrive en passant par ce programme.

---

## Mission 3 — ACL POSIX

- **Accès pour l'auditeur** : avec `setfacl -R -m u:audit-ext:rX`, audit-ext peut lire le dossier `transport/` sans faire partie du groupe. Un `+` apparaît alors dans `ls -ld`, et il ne peut toujours pas écrire.
- **ACL par défaut** : sans elles, les nouveaux fichiers n'ont pas d'entrée pour l'auditeur. En testant, j'ai remarqué que `nouvelle.csv` restait quand même lisible. C'était seulement parce que le umask 002 de nadia donne la lecture à **tout le monde**, ce qui n'est pas vraiment ce qu'on veut. J'ai donc ajouté des ACL par défaut (`setfacl -d`) : chaque nouveau fichier reçoit une entrée `audit-ext:r` et `o::---`, ce qui retire l'accès aux autres.

![ACL par défaut sur transport/ et héritage sur un nouveau fichier](captures/ecrans/acl-defaut.png)
*Les ACL par défaut du dossier, et leur héritage sur un fichier créé ensuite.*

### Le piège du masque avec `chmod g-w`

C'est la partie qui m'a le plus surpris. Sur un fichier qui a des ACL, `chmod g-w` **ne touche pas au groupe propriétaire** : il modifie le **masque**. Le masque fixe le maximum de droits que peuvent avoir le groupe et toutes les entrées ACL nommées.

Concrètement, après `chmod g-w`, tarek a toujours `rwx` dans son entrée, mais `getfacl` affiche `#effective:r-x`, et il ne peut plus écrire dans le fichier. Pour rétablir ses droits, il faut remettre le masque avec `setfacl -m m::rwx`.

![getfacl avant / après chmod g-w : lignes #effective](captures/ecrans/masque-acl.png)
*Après `chmod g-w`, le masque passe à `r-x` et les droits effectifs de tarek baissent.*

### Sauvegarde des ACL

J'ai sauvegardé les ACL avec `getfacl -R` (le fichier est dans `configs/`), je les ai effacées, puis restaurées avec `setfacl --restore`. J'ai aussi constaté que :
- `cp -a` garde les ACL ;
- `cp -r` les perd ;
- `tar --acls --xattrs` les conserve dans l'archive.

![Bilan de tp2.sh : setgid, sticky, umask, setuid, ACL, masque, sudo](captures/ecrans/bilan-tp2.png)
*Le récapitulatif des résultats des missions 1 à 4.*

---

## Mission 4 — Délégation sudo

Le fichier `/etc/sudoers.d/90-helios-ops`, que j'ai validé avec `visudo -c`, permet au groupe `helios-ops` de :
- démarrer, arrêter et redémarrer `helios-collect` et `helios.target` ;
- lire leurs journaux ;
- lire la télémétrie **en tant que `helios`**, et pas en tant que root, ce qui limite les risques.

Toutes les sessions sont enregistrées (`log_output`), et un avertissement s'affiche à chaque utilisation de sudo (`lecture=always`).

- `sudo -l -U julien` montre que Julien peut redémarrer `helios-collect`, mais pas `sshd`.
- `sudoreplay -l` contient bien les 6 sessions de Julien.

![sudo -l -U julien : helios-collect autorisé, sshd refusé](captures/ecrans/sudo-l.png)
*Julien a le droit de gérer helios-collect, mais pas sshd.*

![sudoreplay -l : sessions de julien enregistrées](captures/ecrans/sudoreplay.png)
*Les sessions sudo de Julien sont bien enregistrées.*

### Pourquoi une règle trop large est dangereuse

J'ai testé la règle `nadia ALL=(root) NOPASSWD: /usr/bin/vim …`. On pourrait croire qu'elle permet seulement d'éditer des fichiers. Mais depuis vim, la commande `:!/usr/bin/id` affiche **`uid=0(root)`** : Nadia obtient un shell root sans aucun mot de passe.

Au passage, `vim` n'était pas installé sur mon serveur (en installation minimale, il n'y a que `vi`). J'ai dû installer `vim-enhanced` pour faire ce test.

La bonne solution, c'est **`sudoedit`**. Nadia modifie une copie temporaire du fichier avec ses propres droits, puis sudo recopie le résultat. Elle ne peut donc plus lancer de commande en root. J'ai vérifié qu'elle peut toujours modifier le fichier de cette façon.

![sudo vim : id → uid=0(root) ; correction par sudoedit](captures/ecrans/evasion-sudo-vim.png)
*Depuis `sudo vim`, la commande `id` répond root, d'où la correction par sudoedit.*

![Mot de passe faible refusé, faillock 5 échecs, sudoedit OK](captures/ecrans/bilan-final.png)
*Les derniers tests : mot de passe faible refusé, faillock et sudoedit validés.*

---

## Bonus — Audit (5 constats)

J'ai relevé ces constats avec les commandes de l'énoncé (`captures/bonus-audit.txt`) :

| # | Ce que j'ai constaté | Ce que je propose |
|---|---|---|
| 1 | Les 4 comptes ont le même mot de passe de départ. | Obliger chacun à le changer à sa première connexion : `chage -d 0 <utilisateur>` |
| 2 | `audit-ext` garde un shell `/bin/bash` et son accès aux fichiers jusqu'à la fin de sa mission. | À la fin de la mission : `usermod -L -s /sbin/nologin audit-ext` et `setfacl -R -x u:audit-ext /srv/helios/projets/transport` |
| 3 | `/srv/helios/depot` est le seul dossier où tout le monde peut écrire (1777). | Le réserver au groupe : `chgrp transport /srv/helios/depot && chmod 3770 /srv/helios/depot` |
| 4 | `tournee-j2.csv` garde une ACL `user:tarek:rwx` qui vient de mon test sur le masque. C'est une exception que personne ne pensera à retirer. | `setfacl -x u:tarek /srv/helios/projets/transport/tournee-j2.csv` |
| 5 | La règle `!DANGEREUX` ne protège pas vraiment : une liste noire se contourne facilement, par exemple en copiant `vim` sous un autre nom. | Ne compter que sur la liste des commandes autorisées, et vérifier régulièrement `sudo -l` pour chaque membre. |
