#!/usr/bin/bash
# tp2-reprise2.sh — derniers tests : mot de passe faible (1.3) et sudoedit (4.3).
# pty-expect est lance EN TANT QUE l'utilisateur : « su -c » retire le terminal,
# alors que passwd et sudoedit en exigent un.
set -uo pipefail
source "$(dirname "$0")/lib.sh"
exiger_root; exiger_hote srv-core

PW='Helios-TP2-2026'      # mot de passe de TEST impose par l'enonce
T=/srv/helios/projets/transport
PX=/usr/local/bin/pty-expect
install -m 0755 "$(dirname "$0")/pty-expect.py" $PX

F=m1-mdp-faible.txt; : > "$CAP/$F"
titre "1.3 — Refus d'un mot de passe faible (pam_pwquality)"
chage -d "$(date -d yesterday +%F)" julien
marque $F "julien lance passwd et propose « helios »"
su - julien -c "LC_ALL=C $PX passwd '$PW' helios helios helios helios helios helios" 2>&1 | tr -d '\r' | tee -a "$CAP/$F"
if grep -q 'BAD PASSWORD' "$CAP/$F"; then
    ok "Mot de passe faible refuse"; valeur MDP_FAIBLE "$(grep -m1 'BAD PASSWORD' "$CAP/$F")"
else
    ko "Pas de BAD PASSWORD — voir captures/$F"
fi

F=m4-sudoedit.txt; : > "$CAP/$F"
titre "4.3 — Correction : sudoedit"
run $F "cat /etc/sudoers.d/91-nadia-edition ; visudo -c"
printf '#!/bin/sh\necho "# ligne ajoutee via sudoedit" >> "$1"\n' > /usr/local/bin/editeur-test; chmod 755 /usr/local/bin/editeur-test
su - nadia -c "SUDO_EDITOR=/usr/local/bin/editeur-test $PX 'sudoedit $T/tournee-nadia.csv' '$PW'" 2>&1 | tr -d '\r' | tee -a "$CAP/$F"
run $F "tail -2 $T/tournee-nadia.csv ; ls -l $T/tournee-nadia.csv"
if grep -q 'ajoutee via sudoedit' $T/tournee-nadia.csv; then
    ok "sudoedit : nadia a modifie le fichier sans obtenir de shell root"; valeur SUDOEDIT "fichier modifie via sudoedit, editeur lance avec les droits de nadia"
else
    ko "sudoedit n'a pas modifie le fichier"
fi
rm -f /usr/local/bin/editeur-test

titre "Bilan final"
grep -E '^(MDP_FAIBLE|ECHECS|EVASION|SUDOEDIT)=' "$VALEURS"
info "Si les 4 lignes sont la : bash remplir-rapport.sh"
