#!/usr/bin/bash
# tp2-reprise.sh — refait seulement les 3 tests qui ont echoue au premier passage :
# mot de passe faible (1.3), verrouillage faillock (1.3), evasion sudo vim + sudoedit (4.3).
# A lancer sur srv-core, en root, APRES tp2.sh.
set -uo pipefail
source "$(dirname "$0")/lib.sh"
exiger_root; exiger_hote srv-core

PW='Helios-TP2-2026'      # mot de passe de TEST impose par l'enonce
T=/srv/helios/projets/transport
install -m 0755 "$(dirname "$0")/pty-expect.py" /usr/local/bin/pty-expect
PX=/usr/local/bin/pty-expect        # chemin complet : /usr/local/bin n'est pas dans le PATH de root

########################################################################
F=m1-authselect.txt; : > "$CAP/$F"
titre "1.1 — Activer faillock (le systeme n'etait pas gere par authselect)"
run $F "authselect current"
if ! authselect current &>/dev/null; then
    P=sssd; authselect list 2>/dev/null | grep -q '^- local' && P=local
    info "Aucun profil authselect actif : on selectionne le profil « $P » avec faillock (sauvegarde automatique de /etc/pam.d)"
    run $F "authselect select $P with-faillock --force --backup=avant-tp2"
else
    run $F "authselect enable-feature with-faillock"
fi
run $F "authselect current"
run $F "grep -E 'faillock|pwquality' /etc/pam.d/system-auth"
grep -q pam_faillock /etc/pam.d/system-auth && ok "pam_faillock actif" || ko "pam_faillock toujours absent de system-auth"

########################################################################
F=m1-mdp-faible.txt; : > "$CAP/$F"
titre "1.3 — Refus d'un mot de passe faible (pam_pwquality)"
chage -d "$(date -d yesterday +%F)" julien
marque $F "su - julien puis passwd, nouveau mot de passe « helios »"
$PX "su - julien -c passwd" "$PW" helios helios helios helios helios helios 2>&1 | tr -d '\r' | tee -a "$CAP/$F"
if grep -q 'BAD PASSWORD' "$CAP/$F"; then
    ok "Mot de passe faible refuse"
    valeur MDP_FAIBLE "$(grep -m1 'BAD PASSWORD' "$CAP/$F")"
else
    ko "Pas de BAD PASSWORD — voir captures/$F"
fi

########################################################################
F=m1-faillock.txt; : > "$CAP/$F"
titre "1.3 — Verrouillage apres 5 echecs (pam_faillock)"
faillock --user nadia --reset
marque $F "6 tentatives de su vers nadia avec un mauvais mot de passe, depuis tarek"
for i in $(seq 1 6); do
    su - tarek -c "pty-expect 'su - nadia -c id' mauvais" 2>&1 | tr -d '\r' | tail -1 | tee -a "$CAP/$F"
done
marque $F "AVANT reset"
run $F "faillock --user nadia"
ECHECS=$(faillock --user nadia | tail -n +3 | grep -c .)
valeur ECHECS "$ECHECS"
(( ECHECS >= 5 )) && ok "$ECHECS echecs enregistres -> nadia verrouillee" || ko "$ECHECS echec(s) seulement"
marque $F "Le bon mot de passe est refuse tant que le compte est verrouille"
su - tarek -c "pty-expect 'su - nadia -c id' '$PW'" 2>&1 | tr -d '\r' | tee -a "$CAP/$F"
marque $F "APRES reset"
run $F "faillock --user nadia --reset ; faillock --user nadia"

########################################################################
F=m4-evasion.txt; : > "$CAP/$F"
titre "4.3 — Regle laxiste : evasion de shell via sudo vim"
rpm -q vim-enhanced &>/dev/null || run $F "dnf -y -q install vim-enhanced"
echo 'nadia ALL=(root) NOPASSWD: /usr/bin/vim /srv/helios/projets/transport/*' > /etc/sudoers.d/99-mauvais-exemple
chmod 0440 /etc/sudoers.d/99-mauvais-exemple
run $F "cat /etc/sudoers.d/99-mauvais-exemple ; visudo -c"
marque $F "nadia : sudo vim puis :!/usr/bin/id dans vim"
run $F "su - nadia -c \"id ; sudo vim $T/tournee-nadia.csv -E -s -c '!/usr/bin/id' -c 'q!'\""
if grep -q 'uid=0(root)' "$CAP/$F"; then
    ok "Evasion prouvee : id -> root depuis vim"; valeur EVASION "uid=0(root) obtenu depuis vim"
else
    ko "Evasion non capturee — voir captures/$F"
fi
rm -f /etc/sudoers.d/99-mauvais-exemple

marque $F "Correction : sudoedit"
printf '%s\n' 'Defaults:nadia !sudoedit_checkdir' 'nadia ALL=(root) sudoedit /srv/helios/projets/transport/*' > /etc/sudoers.d/91-nadia-edition
chmod 0440 /etc/sudoers.d/91-nadia-edition
cp /etc/sudoers.d/91-nadia-edition "$CFG/"
run $F "visudo -c"
printf '#!/bin/sh\necho "# ligne ajoutee via sudoedit" >> "$1"\n' > /usr/local/bin/editeur-test; chmod 755 /usr/local/bin/editeur-test
$PX "su - nadia -c 'SUDO_EDITOR=/usr/local/bin/editeur-test sudoedit $T/tournee-nadia.csv'" "$PW" 2>&1 | tr -d '\r' | tee -a "$CAP/$F"
run $F "tail -1 $T/tournee-nadia.csv"
grep -q 'ajoutee via sudoedit' $T/tournee-nadia.csv && ok "sudoedit fonctionne" || ko "sudoedit n'a pas modifie le fichier"
marque $F "Apres correction, sudo vim est refuse a nadia"
run $F "su - nadia -c \"sudo -n vim $T/tournee-nadia.csv -E -s -c '!/usr/bin/id' -c 'q!'\""
rm -f /usr/local/bin/editeur-test

valeur ACL_DEFAUT "avant ACL par defaut : lisible seulement grace aux droits « autres » (umask 002) ; apres : lisible via l'ACL nominative, avec o::--- pour les autres"

titre "Bilan reprise"
grep -E '^(MDP_FAIBLE|ECHECS|EVASION)=' "$VALEURS"
info "Si les 3 lignes sont presentes : bash remplir-rapport.sh"
