#!/usr/bin/python3
"""pty-expect : lance une commande dans un vrai pseudo-terminal et repond a ses invites.
Usage : pty-expect "commande" reponse1 [reponse2 ...]
Chaque reponse est envoyee quand la sortie se termine par ':' (invite de mot de passe).
Sert au TP2 pour su et passwd, qui exigent un terminal."""
import os, pty, select, sys, time

cmd, reponses = sys.argv[1], list(sys.argv[2:])
pid, fd = pty.fork()
if pid == 0:
    os.execvp("bash", ["bash", "-c", cmd])

tampon, fin = b"", time.time() + 30
while time.time() < fin:
    r, _, _ = select.select([fd], [], [], 0.5)
    if r:
        try:
            data = os.read(fd, 1024)
        except OSError:
            break
        if not data:
            break
        sys.stdout.write(data.decode(errors="replace"))
        sys.stdout.flush()
        tampon += data
        if reponses and tampon.rstrip().endswith(b":"):
            time.sleep(0.3)
            os.write(fd, (reponses.pop(0) + "\n").encode())
            tampon = b""
    elif os.waitpid(pid, os.WNOHANG)[0]:
        break
try:
    _, status = os.waitpid(pid, 0)
    sys.exit(os.waitstatus_to_exitcode(status))
except ChildProcessError:
    sys.exit(0)
