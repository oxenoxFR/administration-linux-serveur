# TP2 — Gestion avancée des utilisateurs et des groupes

**David** · BTC2 Administration Linux Server · VM `srv-core` (Rocky Linux 9.8)

Les fichiers de config sont dans `configs/`, les sorties de commandes dans `captures/`.

---

## Mission 1 — Comptes et politique d'authentification

La politique est réglée **avant** de créer les comptes, car un compte hérite des règles en vigueur au moment de sa création.

- **`login.defs`** : mot de passe valable 90 jours, changement possible au plus une fois par jour, avertissement 14 jours avant, `UMASK 027`. Le diff est dans `configs/login.defs.diff`.
- **`pwquality`** : 12 caractères minimum, 3 types de caractères, pas de mot du dictionnaire, règles appliquées aussi à root.
- **`faillock`** : activé avec `authselect enable-feature with-faillock`. Le compte est verrouillé 10 min après 5 échecs en 15 min.

Comptes créés : `julien` (chef d'équipe, groupe `helios-ops`), `nadia`, `tarek` (groupe principal `telemetry`) et `audit-ext`, dont le compte **expire le nov. 24, 2026** (mandat de 3 semaines).

| Vérification | Résultat |
|---|---|
| `chage -l julien` | max 90 jours, avertissement 14 jours |
| Mot de passe `helios` | `BAD PASSWORD: The password is shorter than 12 characters` |
| `faillock --user nadia` après 6 échecs | 5 échecs enregistrés, puis `--reset` vide la liste |

`gpasswd -A julien transport` fait de Julien l'administrateur du groupe : il a ajouté Nadia lui-même, sans être root.

![Mot de passe « helios » refusé par pam_pwquality](captures/ecrans/mdp-faible.png)
*Mot de passe « helios » refusé par pam_pwquality*

![faillock : 5 échecs, le bon mot de passe est refusé, puis --reset](captures/ecrans/faillock.png)
*faillock : 5 échecs, le bon mot de passe est refusé, puis --reset*

---

## Mission 2 — Bits spéciaux et umask

### setgid et sticky

- `transport/` est en **2770** (setgid) : tout fichier créé dedans prend le groupe du dossier. Résultat : transport/ -> groupe transport ; temoin/ -> groupe telemetry.
- `/srv/helios/depot` est en **1777** (sticky) : tout le monde peut écrire, mais chacun ne peut supprimer que ses propres fichiers. Résultat : avec sticky rc=1 (refuse) ; sans sticky rc=0 (autorise).

![Héritage setgid (transport vs telemetry) et refus du sticky bit](captures/ecrans/setgid-sticky.png)
*Héritage setgid (transport vs telemetry) et refus du sticky bit*

### umask (prédit avant, puis observé)

umask de base de nadia : `0027`. Calcul : fichier = 666 − umask, dossier = 777 − umask.

| Cas | Prédit | Observé |
|---|---|---|
| umask par défaut (027) | fichier 640 / dossier 750 | 640 / dossier 750 |
| `umask 002` | fichier 664 / dossier 775 | 664 / dossier 775 |
| `umask 077` | fichier 600 | 600 |

Avec `/etc/profile.d/helios-umask.sh`, nadia (membre de `transport`) passe en `0002` pour le travail en commun, et audit-ext reste en `0027`.

![umask mesuré pour les 3 cas, puis umask par groupe](captures/ecrans/umask.png)
*umask mesuré pour les 3 cas, puis umask par groupe*

### setuid

**Inventaire** : la liste complète est dans `captures/m2-setuid.txt`. Trois binaires justifiés :
- `passwd` (setuid root) : un utilisateur doit pouvoir changer son mot de passe, donc écrire dans `/etc/shadow`, qui appartient à root.
- `sudo` (setuid root) : il doit devenir root pour lancer les commandes autorisées par `sudoers`.
- `su` (setuid root) : il doit changer d'identité après avoir vérifié le mot de passe.

**Script setuid** : un script en 4755 qui lance `id` renvoie toujours `uid=5101(nadia)`. Le noyau ignore le bit setuid sur les scripts interprétés, pour des raisons de sécurité.

**Cas légitime** : `helios-lastlog` (`-rwxr-sr-x`) est setgid `telemetry` et pas setuid root. Il donne juste le droit de lire `app.log`, avec un chemin et un environnement figés. Résultat : tail direct rc=1 (refuse) ; helios-lastlog rc=0 (OK).

---

## Mission 3 — ACL POSIX

- **Accès nominatif** : `setfacl -R -m u:audit-ext:rX` permet à l'auditeur de lire `transport/` sans être dans le groupe. `ls -ld` affiche alors un `+`, et l'écriture lui reste refusée.
- **ACL par défaut** : sans elles, un nouveau fichier n'a pas d'entrée pour l'auditeur. Ici, `nouvelle.csv` restait quand même lisible, mais seulement parce que le umask 002 de nadia donne `r` à **tout le monde**, ce qui n'est pas le comportement voulu. Avec `setfacl -d`, chaque nouveau fichier hérite d'une entrée `audit-ext:r` et de `o::---`. Résultat : avant ACL par defaut : lisible seulement grace aux droits « autres » (umask 002) ; apres : lisible via l'ACL nominative, avec o::--- pour les autres.

![ACL par défaut sur transport/ et héritage sur un nouveau fichier](captures/ecrans/acl-defaut.png)
*ACL par défaut sur transport/ et héritage sur un nouveau fichier*

### Le piège du masque (`chmod g-w`)

Sur un fichier qui a des ACL, `chmod g-w` **ne modifie pas le groupe propriétaire** : il modifie le **masque**. Le masque est la limite maximale de toutes les entrées ACL nommées et du groupe. Après `chmod g-w`, `tarek` garde `rwx` dans son entrée, mais `getfacl` affiche `#effective:r-x` : il ne peut plus écrire. Il faut rétablir le masque avec `setfacl -m m::rwx`. Résultat : apres chmod g-w rc=1 (refuse) ; apres m::rwx rc=0 (OK).

![getfacl avant / après chmod g-w : lignes #effective](captures/ecrans/masque-acl.png)
*getfacl avant / après chmod g-w : lignes #effective*

### Sauvegarde

`getfacl -R` sauvegarde les ACL (`configs/acl-transport-*.txt`) et `setfacl --restore` les remet. `cp -a` conserve les ACL, mais `cp -r` les perd. `tar --acls --xattrs` les conserve dans l'archive.


![Bilan de tp2.sh : setgid, sticky, umask, setuid, ACL, masque, sudo](captures/ecrans/bilan-tp2.png)
*Bilan de tp2.sh : setgid, sticky, umask, setuid, ACL, masque, sudo*

---

## Mission 4 — Délégation sudo

`/etc/sudoers.d/90-helios-ops` (validé avec `visudo -c`) donne au groupe `helios-ops` :
- la gestion de `helios-collect` et de `helios.target` ;
- la lecture de leurs journaux ;
- la lecture de la télémétrie **en tant que `helios`** et pas en root.

Les sessions sont enregistrées (`log_output`) et chaque utilisation de sudo affiche un avertissement (`lecture=always`).

- `sudo -l -U julien` autorise bien `restart helios-collect.service`, mais **pas** `restart sshd`.
- `sudoreplay -l` contient 6 session(s) de julien.

![sudo -l -U julien : helios-collect autorisé, sshd refusé](captures/ecrans/sudo-l.png)
*sudo -l -U julien : helios-collect autorisé, sshd refusé*

![sudoreplay -l : sessions de julien enregistrées](captures/ecrans/sudoreplay.png)
*sudoreplay -l : sessions de julien enregistrées*

**Règle laxiste** : `nadia ALL=(root) NOPASSWD: /usr/bin/vim …` semble limitée à l'édition, mais dans vim, `:!/usr/bin/id` donne **uid=0(root) obtenu depuis vim** : c'est un shell root. La correction est **`sudoedit`** : nadia modifie une copie temporaire avec ses propres droits, et seul sudo réécrit le fichier.


![sudo vim : id → uid=0(root) ; correction par sudoedit](captures/ecrans/evasion-sudo-vim.png)
*sudo vim : id → uid=0(root) ; correction par sudoedit*

![Mot de passe faible refusé, faillock 5 échecs, sudoedit OK](captures/ecrans/bilan-final.png)
*Mot de passe faible refusé, faillock 5 échecs, sudoedit OK*

---

## Bonus — Audit (5 constats)

Constats relevés avec les commandes de l'énoncé (`captures/bonus-audit.txt`).

| # | Constat | Remédiation |
|---|---|---|
| 1 | Les 4 comptes ont le même mot de passe initial | `chage -d 0 <user>` pour forcer le changement à la 1ʳᵉ connexion |
| 2 | `audit-ext` garde un shell `/bin/bash` et l'accès ACL jusqu'à la fin du mandat | À la fin : `usermod -L -s /sbin/nologin audit-ext` et `setfacl -R -x u:audit-ext /srv/helios/projets/transport` |
| 3 | `/srv/helios/depot` est le seul dossier accessible en écriture à tout le monde (1777) | Limiter au groupe : `chgrp transport /srv/helios/depot && chmod 3770 /srv/helios/depot` |
| 4 | `tournee-j2.csv` garde une ACL `user:tarek:rwx` laissée par le test du masque : une exception nominative que personne ne suivra | `setfacl -x u:tarek /srv/helios/projets/transport/tournee-j2.csv` |
| 5 | La règle `!DANGEREUX` ne protège pas tout : une liste noire se contourne (copie de `vim` sous un autre nom) | S'appuyer sur la liste blanche seulement, et vérifier `sudo -l` de chaque membre |
